import unittest
import function

class UnitTest(unittest.TestCase):
    def test_addition(self):
        result = function.addition(10,5)
        self.assertEqual(result,15)

    def test_subtraction(self):
        self.assertEqual(function.subtraction(10,5),5)
        self.assertEqual(function.subtraction(1, 1), 0)
        self.assertEqual(function.subtraction(-1,-1), 0)

    def test_multiplication(self):
        self.assertEqual(function.multiplication(10, 5), 50)
        self.assertEqual(function.multiplication(0, 5), 0)
        self.assertEqual(function.multiplication(10, -5), -50)

    def test_division(self ):
        self.assertEqual(function.division(10, 5), 2)
        self.assertEqual(function.division(10, 10), 1)
        self.assertEqual(function.division(5, 2), 2.5)

    def test_exponentiation(self):
        self.assertEqual(function.exponentiation(10, 2), 100)
        self.assertEqual(function.exponentiation(2, 3), 8)
        self.assertEqual(function.exponentiation(3, 2), 9)

if __name__ == "__main__":
    unittest.main()